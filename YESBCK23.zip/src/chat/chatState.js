export const activeConnections = new Map(); // userId -> WebSocket
export const pendingTimeouts = new Map(); // userId -> timeoutId
